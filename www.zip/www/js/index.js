(function(){
    var data = {
        quizContent: [
            {
                 "question": "iOS stands for ?",
                "answer1": "Internetwork Operating System",
                "answer2": "iPhone Operating System",
                "answer3": "Internet Operating System",
               
                fact:"The correct answer is iPhone Operating System",
                correctAnswer: 2
            },
            {
               "question": "Which of the following framework is not used in iOS?",
                "answer1": "UIKit Framework",
                "answer2": "AppKit Framework",
                "answer3": "Foundation Framework",
                fact:"The correct answer is AppKit framework",
                
                correctAnswer: 2
            },
{
                "question":  "Which of the following hierarchy is correct?",
                "answer1": "UIButton->UIControl->UIView->NSObject->UIResponder",
                "answer2": "UIControl->UIButton->UIView->UIResponder->NSObject",
                "answer3": "UIButton->UIControl->UIView->UIResponder->NSObject",
              
                fact:"The correct answer is UIButton->UIControl->UIView->UIResponder->NSObject ",
                correctAnswer: 3
            },

 {
               "question": "Which of the following iOS frameworks is a commonly used third party Library?",
                "answer1": "AVFoundation.framework",
                "answer2": "Audiotoolbox.framework",
                "answer3": "AFNetwork.framework",
                
                fact:"The correct answer is AFNetwork.framework",
                
                correctAnswer: 3
            },
             {
               "question": "The application has not been launched or was running but terminated by the device.Determine the current state of App.?",
                "answer1": "Suspended state",
                "answer2": "Inactive state",
                "answer3": "Not running state",
                
                fact:"The correct answer is Not running state",
                
                correctAnswer: 3
            },
             {
               "question": "The Iphone has a feature that activates when you rotate the device from portrait to landscape?",
                "answer1": "Accelerometer",
                "answer2": "Rotator",
                "answer3": "Special sensor",
                
                fact:"The correct answer is Accelerometer",
                
                correctAnswer: 1
            },
             {
               "question": "Flash Applications is  supported in iPhone browsers.Is it true?",
                "answer1": "Yes",
                "answer2": "No",
                "answer3": "Supports partially",
                
                fact:"The correct answer is Yes",
                
                correctAnswer: 1
            },
             {
               "question": "What is facetime in Apple?",
                "answer1": "Taking videos",
                "answer2": "Editing photos",
                "answer3": "Video calls",
                
                fact:"The correct answer is Video calls",
                
                correctAnswer: 3
            },
             {
               "question": "Application running in foreground but currently not receiving any events.What is the current state of Application?",
                "answer1": "Background state",
                "answer2": "Inactive State",
                "answer3": "Active state",
                
                fact:"The correct answer is Inactive State",
                
                correctAnswer: 2
            },
             {
               "question": "Which of the following statement is wrong?",
                "answer1": "IBAction is a type qualifier used by IB to enable connection user experience elements and app code",
                "answer2": "IBAction is a macro defined to denote a method that can be referred to in Interface Builder.",
                "answer3": "None of them",
                
                fact:"The correct answer is None of them",
                
                correctAnswer: 3
            },
             {
               "question": "The Iphone camera can",
                "answer1": "Autofocus",
                "answer2": "Record videos",
                "answer3": "Make digital photos",
                
                fact:"The correct answer is Make digital photos",
                
                correctAnswer: 3
            },
             {
               "question": "Application is in background. Not executing any code.What is the current application state?",
                "answer1": "Inactive state",
                "answer2": "Active state",
                "answer3": "Suspended state",
                
                fact:"The correct answer is Suspended state",
                
                correctAnswer: 3
            },
             {
               "question": "Which of the following statement is wrong?",
                "answer1": "IBOutlet resolves to Id",
                "answer2": "IBOutlet resolves to nothing",
                "answer3": "IBOutlet are macro defined to denote a variable  that can be referred to in Interface Builder.",
                
                fact:"The correct answer is IBOutlet resolves to nothing",
                
                correctAnswer: 2
            },
             {
               "question": "Application in background & executing background tasks.Determine current state of Application?",
                "answer1": "Background state",
                "answer2": "Inactive state",
                "answer3": "Suspended state",
                
                fact:"The correct answer is Background state",
                
                correctAnswer: 1
            },
             {
               "question": "iOS remote push notification is introduced by apple in which version?",
                "answer1": "iOS 2.0",
                "answer2": "iOS 6.0",
                "answer3": "iOS 3.0",
                
                fact:"The correct answer is iOS 3.0",
                
                correctAnswer: 3
            },
             {
               "question": "Which of the following is a default UI property?",
                "answer1": "assign",
                "answer2": "non-atomic",
                "answer3": "atomic",
                
                fact:"The correct answer is atomic",
                
                correctAnswer: 3
            },

             {
               "question": "Multitasking in iOS was introduced in which version?",
                "answer1": "iOS 2.0",
                "answer2": "OS 4.0",
                "answer3": "iOS 7.0",
                
                fact:"The correct answer is OS 4.0",
                
                correctAnswer: 2
            },


            {
                "question":  "Application is running in foreground and receiving events.What is the current App State?",
                "answer1": "Inactive state",
                "answer2": "Background state",
                "answer3": "Active state",
              
                fact:"The correct answer is Inactive state",
                correctAnswer: 1
            },
            {
                question: "Which keyword do you use to declare enumeration?",
                answer1: "var",
                answer2: "let",
                answer3: "enum",
                fact:"The correct answer is enum",
                correctAnswer: 3
            },
            {
                question  : "What built-in database is Android shipped with?",
                answer1  : "SQLite",
                answer2  : "Apache",
                answer3  : "Oracle",
                fact:"The correct answer is SQLite",
                correctAnswer: 1
                  }
        ],
        points: 0
    };
    var display = {
        getApp: document.getElementById('app'),
        mainPage: function() {
            var newEl = '<div class="quest-number"><p id="questNumber"></p></div><h1 id="questionDisplay" class="h3"></h1>';
                newEl += '<ul><li><label><input type="radio" name="answers" id="input1" value="1"><span class="outer"><span class="inner"></span></span><div id="answerDisplay1"></div></label></li>';
                newEl += '<li><label><input type="radio" name="answers" id="input2" value="2"><span class="outer"><span class="inner"></span></span><div id="answerDisplay2"></div></label></li>';
                newEl += '<li><label><input type="radio" name="answers" id="input3" value="3"><span class="outer"><span class="inner"></span></span><div id="answerDisplay3"></div></label></li></ul>';
                newEl += '<div class="points-wrap"><p id="currentPoints"></p></div>';
            this.getApp.innerHTML = newEl;
        },
        
        updateMainPage: function() {
            var getQuestNumber = document.getElementById('questNumber'),
                getQuestion = document.getElementById('questionDisplay'),
                getAnswer1 = document.getElementById('answerDisplay1'),
                getAnswer2 = document.getElementById('answerDisplay2'),
                getAnswer3 = document.getElementById('answerDisplay3'),
               
                getCurrentPoints = document.getElementById('currentPoints'),
                sumOfQuestions = data.quizContent.length;
                
            getQuestNumber.innerHTML = control.count + 1 + '/' + sumOfQuestions;
            getQuestion.innerHTML = data.quizContent[control.count].question;

            getAnswer1.innerHTML = data.quizContent[control.count].answer1;
            getAnswer2.innerHTML = data.quizContent[control.count].answer2;
            getAnswer3.innerHTML = data.quizContent[control.count].answer3;
         
            getCurrentPoints.innerHTML = 'Points:' + ' ' + data.points;
            this.newElement('button', 'submit', 'Check');
        },
        addAnswer: function(showMessage) {
            var sumOfQuestions = data.quizContent.length;

            if(showMessage === 'correct') {
                this.newElement('p', 'showAnswer', 'Correct');
            } else {
                var x=data.quizContent[control.count].fact    
                this.newElement('p', 'showAnswer', 'Incorrect....'+x );
            }

            if (control.count < sumOfQuestions - 1) {
                this.newElement('button', 'nextQuest', 'Next question');
            } else {
                this.newElement('button', 'result', 'See your result');
            }
        },
        removeAnswer: function(event) {
            var getShowAnswer = document.getElementById('showAnswer');
            var getShowAnswerParent = getShowAnswer.parentNode;
            getShowAnswerParent.removeChild(getShowAnswer);
            var clickedEl = event.target;
            var clickedElParent = clickedEl.parentNode;
            clickedElParent.removeChild(clickedEl);
            var radioButtons = document.getElementsByName('answers');
            var allRadioButtons = radioButtons.length;
            var i;
            for(i = 0; i < allRadioButtons; i++) {
                radioButtons[i].checked = false;
            }
        },
        resultPage: function() {
            this.getApp.innerHTML = '<h1 class="h3">You have ' + data.points + ' correct answers</h1>';
            this.newElement('button', 'restart', 'Restart Quiz');
        },
        newElement: function(elem, elemId, elemText) {
            var newElem = document.createElement(elem);
            var newElemText = document.createTextNode(elemText);
            newElem.appendChild(newElemText);
            newElem.id = elemId;
            this.getApp.appendChild(newElem);
        }
    };
    var control = {
        init: function() {
            var start = document.getElementById('start') || document.getElementById('restart');
            start.addEventListener('click', function() {
                display.mainPage();
                control.update();
            }, false);
        },
        update: function() {
            display.updateMainPage();
            var submit = document.getElementById('submit');
            submit.addEventListener('click', this.checkAnswer, false);
        },
        checkAnswer: function(event) {
            var radioButtons = document.getElementsByName('answers'),
                allRadioButtons = radioButtons.length,
                isChecked = false,
                checkedRadio,
                clickedEl = event.target,
                clickedElParent = clickedEl.parentNode,
                i;

            for (i = 0; i < allRadioButtons; i++) {
                if (radioButtons[i].checked) {
                    isChecked = true;
                    checkedRadio = +radioButtons[i].value;
                }
            }

            if (isChecked === false) {
                alert('Please select an answer!');
            } else {
                clickedElParent.removeChild(clickedEl);
                if (checkedRadio === data.quizContent[control.count].correctAnswer) {
                    display.addAnswer('correct');
                    data.points++;
                } else {
                    display.addAnswer();
                }
                var nextQuestion = document.getElementById('nextQuest'),
                    result = document.getElementById('result');
                if (nextQuestion) {
                    nextQuestion.addEventListener('click', function(event) {
                        control.count++;
                        display.removeAnswer(event);
                        control.update();
                    }, 
                    false);
                } else {
                    result.addEventListener('click', function() {
                        display.resultPage();
                        control.init();
                        control.count = 0;
                        data.points = 0;
                    }, false);
                }
            }
        },
        count: 0
    };
    control.init();
}
)
();
